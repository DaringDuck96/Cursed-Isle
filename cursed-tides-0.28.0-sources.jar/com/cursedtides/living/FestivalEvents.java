package com.cursedtides.living;

import net.minecraft.world.entity.EntityTypes;
import com.cursedtides.combat.Levels;
import com.cursedtides.entity.CursedPirateEntity;
import com.cursedtides.entity.ModEntities;
import com.cursedtides.entity.ShipEntity;
import com.cursedtides.item.ModItems;
import com.cursedtides.world.Archipelago;
import it.unimi.dsi.fastutil.ints.IntList;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.FireworkExplosion;
import net.minecraft.world.item.component.Fireworks;
import java.util.List;

import static net.minecraft.commands.Commands.literal;

/**
 * The festivals as events, not just bonuses. Each brings its own visitors to the towns (who drop festival tokens),
 * the summer and winter feasts and Saint Vesper's light up the night with fireworks, and Regatta Week pays tokens for
 * every ship you sink. Spend tokens with /festival on a trinket, a treasure chest, or the festival's own title.
 *
 *   Spring Tide Fair: Golden Crabs scuttle on the beaches by day.
 *   Regatta Week: fireworks, and tokens for sinking ships.
 *   Saint Vesper's Feast: Penitent Shades drift through the towns at night; fireworks.
 *   Night of Lanterns: Lantern Ghosts walk the streets after dark.
 *   Salt Harvest: Salt Thieves raid the market stalls by day.
 *   Midwinter Feast: Frost Wraiths at night; fireworks.
 */
public final class FestivalEvents {
    private FestivalEvents() {}

    public static final String TAG = "ct_festival";

    private static List<Archipelago.Island> towns() {
        return Archipelago.ISLANDS.stream().filter(i -> i.style() == Archipelago.Style.TOWN || i == Archipelago.DRIFTWOOD_ISLAND).toList();
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(FestivalEvents::tick);
        ServerLivingEntityEvents.AFTER_DEATH.register((victim, source) -> {
            if (victim.entityTags().contains(TAG) && source.getEntity() instanceof ServerPlayer) {
                com.cursedtides.util.Compat.drop(victim, new ItemStack(ModItems.FESTIVAL_TOKEN, 1 + victim.getRandom().nextInt(2)));
            }
        });
        CommandRegistrationCallback.EVENT.register((d, a, env) -> d.register(literal("festival")
                .executes(ctx -> { info(ctx.getSource().getPlayerOrException()); return 1; })
                .then(literal("trinket").executes(ctx -> { redeem(ctx.getSource().getPlayerOrException(), 0); return 1; }))
                .then(literal("chest").executes(ctx -> { redeem(ctx.getSource().getPlayerOrException(), 1); return 1; }))
                .then(literal("title").executes(ctx -> { redeem(ctx.getSource().getPlayerOrException(), 2); return 1; }))));
    }

    private static void tick(MinecraftServer server) {
        if (!com.cursedtides.world.ModWorld.isArchipelago()) return;
        Festivals.Festival f = Festivals.current();
        if (f == null) return;
        ServerLevel w = server.overworld();
        int t = server.getTickCount();
        boolean night = w.isDarkOutside();
        if (t % 600 == 77) {
            for (ServerPlayer p : w.players()) {
                for (Archipelago.Island town : towns()) {
                    if (Math.hypot(p.getX() - town.cx(), p.getZ() - town.cz()) > town.radius() + 40) continue;
                    visitors(w, f, town, p, night);
                }
            }
        }
        if (night && t % 160 == 31 && (f == Festivals.Festival.REGATTA_WEEK || f == Festivals.Festival.MIDWINTER_FEAST
                || f == Festivals.Festival.SAINT_VESPERS_DAY)) {
            for (Archipelago.Island town : towns()) {
                if (w.getPlayers(q -> Math.hypot(q.getX() - town.cx(), q.getZ() - town.cz()) < 200).isEmpty()) continue;
                fireworks(w, town, f);
            }
        }
    }

    private static void visitors(ServerLevel w, Festivals.Festival f, Archipelago.Island town, ServerPlayer p, boolean night) {
        boolean wantsNight = f == Festivals.Festival.NIGHT_OF_LANTERNS || f == Festivals.Festival.SAINT_VESPERS_DAY || f == Festivals.Festival.MIDWINTER_FEAST;
        if (f == Festivals.Festival.REGATTA_WEEK || wantsNight != night) return;
        if (w.getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(48), m -> m.entityTags().contains(TAG)).size() >= 4) return;
        BlockPos at = Residents.openGround(w, p.getBlockX() + w.getRandom().nextIntBetweenInclusive(-20, 20), p.getBlockZ() + w.getRandom().nextIntBetweenInclusive(-20, 20), 8);
        if (at == null || at.closerThan(p.blockPosition(), 8)) return;
        Mob m;
        String name;
        switch (f) {
            case SPRING_TIDE_FAIR -> { m = com.cursedtides.wildlife.Wildlife.CRAB.create(w, EntitySpawnReason.EVENT); name = "Golden Crab"; }
            case SAINT_VESPERS_DAY -> { m = EntityTypes.VEX.create(w, EntitySpawnReason.EVENT); name = "Penitent Shade"; }
            case NIGHT_OF_LANTERNS -> { m = ModEntities.CURSED_PIRATE.create(w, EntitySpawnReason.EVENT); name = "Lantern Ghost"; }
            case SALT_HARVEST -> { m = EntityTypes.PILLAGER.create(w, EntitySpawnReason.EVENT); name = "Salt Thief"; }
            default -> { m = EntityTypes.STRAY.create(w, EntitySpawnReason.EVENT); name = "Frost Wraith"; }
        }
        if (m == null) return;
        m.snapTo(at.getX() + 0.5, at.getY() + (f == Festivals.Festival.SAINT_VESPERS_DAY ? 2 : 0), at.getZ() + 0.5, w.getRandom().nextFloat() * 360, 0);
        m.finalizeSpawn(w, w.getCurrentDifficultyAt(at), EntitySpawnReason.EVENT, null);
        m.setCustomName(Component.literal(name).withStyle(ChatFormatting.LIGHT_PURPLE));
        m.addTag(TAG);
        if (m instanceof CursedPirateEntity cp) cp.setVariant(CursedPirateEntity.Kind.BONE, CursedPirateEntity.Rank.GRUNT);
        if (f == Festivals.Festival.NIGHT_OF_LANTERNS) m.setItemSlot(net.minecraft.world.entity.EquipmentSlot.HEAD, new ItemStack(Items.JACK_O_LANTERN));
        if (f == Festivals.Festival.SPRING_TIDE_FAIR || f == Festivals.Festival.NIGHT_OF_LANTERNS) {
            m.addEffect(new MobEffectInstance(MobEffects.GLOWING, 20 * 60 * 5, 0, false, false));
        }
        int[] band = Levels.bandAt(at);
        Levels.apply(m, band[0]);
        w.addFreshEntity(m);
    }

    private static void fireworks(ServerLevel w, Archipelago.Island town, Festivals.Festival f) {
        int[][] palette = switch (f) {
            case MIDWINTER_FEAST -> new int[][]{{0xFFFFFF, 0x88CCFF}, {0xCC2222, 0x22AA44}};
            case SAINT_VESPERS_DAY -> new int[][]{{0xFFD24A, 0xFFFFFF}, {0xB088FF, 0xFFD24A}};
            default -> new int[][]{{0xFF4A3A, 0xFFD24A}, {0x3A8AFF, 0xFFFFFF}, {0x3AFF8A, 0xFF3AFF}};
        };
        FireworkExplosion.Shape[] shapes = FireworkExplosion.Shape.values();
        for (int k = 0; k < 3; k++) {
            int[] cols = palette[w.getRandom().nextInt(palette.length)];
            ItemStack rocket = new ItemStack(Items.FIREWORK_ROCKET);
            rocket.set(DataComponents.FIREWORKS, new Fireworks(2, List.of(new FireworkExplosion(
                    shapes[w.getRandom().nextInt(shapes.length)], IntList.of(cols), IntList.of(0xFFFFFF), w.getRandom().nextBoolean(), true))));
            double x = town.cx() + w.getRandom().nextGaussian() * 12, z = town.cz() + w.getRandom().nextGaussian() * 12;
            int y = Math.max(Archipelago.WATER_TOP + 2, Archipelago.column((int) x, (int) z).top() + 2);
            w.addFreshEntity(new FireworkRocketEntity(w, x, y, z, rocket));
        }
    }

    /** Regatta Week pays tokens for every ship sunk. */
    public static void onShipSunk(ServerPlayer p, ShipEntity s) {
        if (Festivals.current() == Festivals.Festival.REGATTA_WEEK) {
            com.cursedtides.quest.QuestData.give(p, new ItemStack(ModItems.FESTIVAL_TOKEN, 2 + s.shipClass().ordinal() / 2));
        }
    }

    private static final int TRINKET = 10, CHEST = 15, TITLE = 25;

    private static void info(ServerPlayer p) {
        Festivals.Festival f = Festivals.current();
        int have = p.getInventory().countItem(ModItems.FESTIVAL_TOKEN);
        if (f == null) {
            p.sendSystemMessage(Component.literal("No festival on just now. (" + have + " tokens saved; they keep.)").withStyle(ChatFormatting.GRAY), false);
            return;
        }
        p.sendSystemMessage(Component.literal(f.title + ": " + f.perk).withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD), false);
        p.sendSystemMessage(Component.literal("You have " + have + " festival tokens. Spend them:").withStyle(ChatFormatting.GRAY), false);
        p.sendSystemMessage(Component.literal("  [A festival trinket: " + TRINKET + "]").withStyle(s -> s.withColor(ChatFormatting.AQUA)
                        .withClickEvent(new ClickEvent.RunCommand("/festival trinket")))
                .append(Component.literal("  [A sea chest: " + CHEST + "]").withStyle(s -> s.withColor(ChatFormatting.GOLD)
                        .withClickEvent(new ClickEvent.RunCommand("/festival chest"))))
                .append(Component.literal("  [The title \"" + honour(f) + "\": " + TITLE + "]").withStyle(s -> s.withColor(ChatFormatting.LIGHT_PURPLE)
                        .withClickEvent(new ClickEvent.RunCommand("/festival title")))), false);
    }

    private static String honour(Festivals.Festival f) {
        return switch (f) {
            case SPRING_TIDE_FAIR -> "Crab Wrangler of the Fair";
            case REGATTA_WEEK -> "Regatta Raider";
            case SAINT_VESPERS_DAY -> "Penitent of Saint Vesper";
            case NIGHT_OF_LANTERNS -> "Lantern-Night Reveller";
            case SALT_HARVEST -> "Salt Warden";
            case MIDWINTER_FEAST -> "Midwinter Merrymaker";
        };
    }

    private static void redeem(ServerPlayer p, int what) {
        Festivals.Festival f = Festivals.current();
        if (f == null) { p.sendSystemMessage(Component.literal("The stalls open when a festival's on.").withStyle(ChatFormatting.GRAY), false); return; }
        int cost = what == 0 ? TRINKET : what == 1 ? CHEST : TITLE;
        if (p.getInventory().countItem(ModItems.FESTIVAL_TOKEN) < cost) {
            p.sendSystemMessage(Component.literal("You need " + cost + " festival tokens.").withStyle(ChatFormatting.RED), false);
            return;
        }
        int left = cost;
        var inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize() && left > 0; i++) {
            ItemStack s = inv.getItem(i);
            if (!s.is(ModItems.FESTIVAL_TOKEN)) continue;
            int k = Math.min(left, s.getCount());
            s.shrink(k);
            left -= k;
        }
        switch (what) {
            case 0 -> com.cursedtides.quest.QuestData.give(p, new ItemStack(com.cursedtides.appearance.Accessories.random(p.getRandom(), true)));
            case 1 -> com.cursedtides.quest.QuestData.give(p, com.cursedtides.combat.Loot.container(com.cursedtides.combat.Loot.Tier.CHEST,
                    Math.max(5, com.cursedtides.pirate.PirateData.notoriety(p))));
            default -> com.cursedtides.social.Titles.grant(p, honour(f));
        }
        p.sendSystemMessage(Component.literal("Happy " + f.title + "!").withStyle(ChatFormatting.LIGHT_PURPLE), false);
    }
}
